const arr=["Amit","Mohan","John","Ram","Shyam","Peter","alex"]

function isUserPresent(name){
        if(arr.includes(name)){
            console.log(`Yes,${name} is a valid user`)
        }
        else{
        console.log(`No,${name} is not a valid user`)
        }

}

isUserPresent("Amit")