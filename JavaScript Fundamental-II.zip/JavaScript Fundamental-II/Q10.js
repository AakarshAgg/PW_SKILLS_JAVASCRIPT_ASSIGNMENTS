const sentence="please please submit your assignment on time, your assignments are important";

function wordCounter(statement){
 let arr= statement.split(/\s+/);
 const wordMap=new Map();
 for(let word of arr){
    const lowerword=word.toLowerCase();
   if(wordMap.has(lowerword)){
       wordMap.set(lowerword,wordMap.get(lowerword)+1)
   }else{
   wordMap.set(lowerword,1)
   }
 }
 return wordMap
}

const result=wordCounter(sentence);



console.log(result)