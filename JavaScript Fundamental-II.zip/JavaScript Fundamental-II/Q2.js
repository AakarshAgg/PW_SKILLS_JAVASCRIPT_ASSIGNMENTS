const CalculateTotalCartValue=(...num)=>{
    let sum=0;
    for(let i=0;i<num.length;i++){
        sum+=num[i];
    }
    return sum;
}


console.log("The total cart value is",CalculateTotalCartValue(125,20,30))