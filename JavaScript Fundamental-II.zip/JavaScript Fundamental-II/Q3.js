const students = [
    {
        name: "Mithun",
        marks: 95,
    },
    {
        name: "Prabir",
        marks: 75,
    },
    {
        name: "Alka",
        marks: 92,
    },
    {
        name: "Shivam",
        marks: 70,
    },
    {
        name: "Farman",
        marks: 99,
    },
]


const checkResults = (name) => {
    let student = students.find(function (items) {
        return items.name === name
    })

    if (student && student.marks>90 ) {
       console.log(`Congratulations ${student.name}! you have cleared the exam.`)
    }
    else if (student) {
        console.log("Sorry! You have not cleared the exam.")
    }
    else {
        console.log("Invalid User!!")
    }
}


checkResults("Mithun")

checkResults("Prabir")

checkResults("Mithun S")
