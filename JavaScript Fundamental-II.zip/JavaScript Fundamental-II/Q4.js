const products = [
    { name: "Laptop", price: 120000 },
    { name: "Mobile", price: 7000 },
    { name: "Laptop Bag", price: 20000 },
    { name: "watch", price: 20000 },
    { name: "Mobile Charger", price: 1500 }
];

function finMinMaxProducts(items) {
    let minProduct = items[0];
    let maxProduct = items[0];

    for (let item of items) {
        if (item.price > items[0].price) {
            maxProduct = item;
        }

        if (item.price < items[0].price) {
            minProduct = item;
        }

    }
    console.log(`The product with maximum amount is ${maxProduct.name} which is priced at Rs.${maxProduct.price}`)
    console.log(`The product with minimum amount is ${minProduct.name} which is priced at Rs.${minProduct.price}`)
}

finMinMaxProducts(products)