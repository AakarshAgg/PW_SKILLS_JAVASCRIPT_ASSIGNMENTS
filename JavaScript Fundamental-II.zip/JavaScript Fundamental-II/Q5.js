const guests=["Anurag","Mithun","Alka","Prabir","Shivam","Farman"]


console.log(guests.join(","))
