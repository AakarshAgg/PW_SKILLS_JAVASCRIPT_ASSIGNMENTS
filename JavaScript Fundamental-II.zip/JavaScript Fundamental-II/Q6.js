const productDetails = {
    name: "Apple 2020 MacBook Air Laptop",
    price: 82000,
    color: "Grey",
    harddisk: "256 GB"
};

console.log(`   Below are the product details
   name:${productDetails.name},
   price:${productDetails.price},
   color:${productDetails.color},
   harddisk:${productDetails.harddisk}
`)