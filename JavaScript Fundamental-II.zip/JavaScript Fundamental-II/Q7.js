
const generateOtp=()=>{
    let min=1000;
    let max=9999;
    let num=Math.floor(Math.random()*(max-min+1))+min
  return num
}


console.log(`Here is your otp: ${generateOtp()}`)