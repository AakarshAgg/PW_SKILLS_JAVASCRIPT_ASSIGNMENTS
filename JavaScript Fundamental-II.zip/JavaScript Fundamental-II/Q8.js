const eventDate="2023-08-31"

function calculateRemainingDays(eventDate){
    let currentDate=new Date()
    let startDate=new Date(eventDate)
    const timeDifference=startDate-currentDate
    let time=Math.floor(timeDifference/(1000*60*60*24))
    return time
}

console.log(calculateRemainingDays(eventDate))