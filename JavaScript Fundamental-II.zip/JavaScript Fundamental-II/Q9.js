function uniqueCharacterCheck(username) {
    const charSet = new Set();
    for (let char of username) {
        if (charSet.has(char)) {
            return console.log("The input string contains duplicates.")
        }
        charSet.add(char)
    }
    return console.log("The input string containes unique characters.")

}

uniqueCharacterCheck("mithun")

uniqueCharacterCheck("anurag")