let totalValue=2000
let discountPercentage=20;

let price=totalValue*(100-discountPercentage)/100;
console.log("The final price after discount is:",price)