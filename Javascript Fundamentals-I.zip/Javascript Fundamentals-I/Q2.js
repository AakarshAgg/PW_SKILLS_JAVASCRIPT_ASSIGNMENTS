let username = "admin";
let password = "12345";

username=="admin" && password=="12345"? console.log("Login Successful"):console.log("Invalid Credentials")