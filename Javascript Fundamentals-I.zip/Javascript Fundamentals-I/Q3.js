let inr = 850;
amount=inr/82;

console.log(`${inr} INR is`,amount,"USD")