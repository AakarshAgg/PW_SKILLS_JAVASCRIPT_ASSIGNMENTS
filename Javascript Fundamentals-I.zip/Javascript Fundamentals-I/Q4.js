let numberOfChilds=2;
let numberOfAdults =1;
let numberOfSeniors=1;

let price=numberOfChilds*100+numberOfAdults*150+numberOfSeniors*120;

console.log("The total ticket price is",price)