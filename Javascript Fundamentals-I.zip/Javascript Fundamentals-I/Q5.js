let package = "overnight";

switch (package) {
    case "standard":
        console.log("This will take 3-5 days")
        break;
    case "express":
        console.log("This will take 1-2 days")
        break;
    case "overnight":
        console.log("This will be delivered next day")
        break;
    default:
        console.log("Invalid package type")
        break;
}