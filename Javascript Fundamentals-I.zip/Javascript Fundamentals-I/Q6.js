let name = "Mithun";
let email="mithun.s@pw.live";
let age = "21";

if(typeof(name)!="string"){
    console.log("Name should be A string ...")

}
if(typeof(email)!="string"){
    console.log("Email should be A String..")
}

if(typeof(age)!="number"){
    console.log("Age Should be A Number..")
}