let shoppingList=["Apple","Mangoes","Banana","strawberry"]

for(let item=0;item<shoppingList.length;item++){
    console.log(shoppingList[item])
}