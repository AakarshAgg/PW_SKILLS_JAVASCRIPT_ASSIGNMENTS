console.log("Counting From 10 to 0")
let i=0
while(i<=10){
    console.log(i)
    i++;
}